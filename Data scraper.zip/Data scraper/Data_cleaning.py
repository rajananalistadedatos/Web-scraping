import pandas as pd
import numpy as np

# 1. Load the Data
df = pd.read_csv(r"C:\Users\Rajan\OneDrive\Desktop\Data scraper\books.csv")

# 2. Handle Missing Values
 #   - Identify missing values
print(df.isnull().sum())

 #   - Handle missing values (e.g., imputation, removal)
 #   - Imputation:
df.fillna(method='ffill', inplace=True)  # Fill missing values with the previous value
 #   - Removal:
df.dropna(inplace=True)  # Remove rows with missing values

#

# 3. Data Cleaning
#   - Remove duplicates
df.drop_duplicates(inplace=True)
#   - Correct inconsistencies (e.g., typos, formatting errors)
df['Title'] = df['Title'].str.strip()  # Remove leading/trailing whitespace
#   - Convert data types
df['Title'] = pd.to_numeric(df['Title'], errors='coerce')

